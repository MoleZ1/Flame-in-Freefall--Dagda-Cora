from flask import Flask
from pymongo import MongoClient

from .config import Config


def create_app(config=Config):
    app = Flask(__name__)
    app.config.from_object(config)

    # One MongoDB client for the whole app
    client = MongoClient(app.config["MONGO_URI"])
    app.extensions["db"] = client[app.config["MONGO_DB"]]

    # Recommendation engine: created ONCE (loads the database and the embeddings index)
    try:
        from motor_psi import Motor
        app.extensions["motor"] = Motor()
        app.extensions["motor_error"] = None
    except Exception as e:
        app.extensions["motor"] = None
        app.extensions["motor_error"] = f"{type(e).__name__}: {e}"
        app.logger.error("motor_psi did not load: %s", e)

    from .pages import pages
    app.register_blueprint(pages)

    from .chat_api import chat_api
    app.register_blueprint(chat_api)

    return app
