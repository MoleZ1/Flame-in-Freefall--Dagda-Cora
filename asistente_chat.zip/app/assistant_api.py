"""
Database assistant (the chat icon on every page).

    POST /api/assistant  {message, history: [{role, content}], context: {page, investigation_id}}
      -> {answer, recommendations, sources, removed_statements, source}

How an answer is built:
  1. The question (plus the previous one, for follow-ups) is searched in the database with motor_psi's ranking:
     meaning (embeddings) + exact words (BM25) + numbers (neighbor experiments), fused with RRF.
  2. The best records, a small catalog of the investigations and, on the Suggestions page, the investigation
     being viewed, are given to Qwen as FACTS. Qwen sees nothing else.
  3. Every sentence of the answer and every recommendation is checked: cited IDs must be among the FACTS and
     numbers must appear in them. Sentences that fail are removed (and counted), never shown.
  4. If Qwen is not available, the most relevant records are listed instead.
"""
from __future__ import annotations

import json
import re

from flask import Blueprint, current_app, jsonify, request

from motor_psi import llm
from motor_psi.narrador import ID_RE, validar

assistant_api = Blueprint("assistant_api", __name__, url_prefix="/api/assistant")

K_SOURCES = 8
SOURCE_CHARS = 650
MAX_HISTORY = 6
TYPE_EN = {"investigacion": "investigation", "dataset": "dataset", "experimento": "experiment",
           "fragmento": "report passage", "hallazgo": "finding"}

SYSTEM = """You are the database assistant of PSI Scientific Advisor (Flame in Freefall): microgravity combustion
experiments from NASA Physical Sciences Informatics, plus investigations uploaded by users (marked user_upload).
Answer in English using ONLY the FACTS you receive. You have no other knowledge of these experiments.
Rules:
1. After each claim, cite the ID it comes from in square brackets, e.g. [PSI-159], [FND:PSI-159:001],
   [PSI-159:normal:21174C5]. Use only IDs that appear in FACTS. Never invent IDs.
2. Do not write any number that does not appear in FACTS.
3. If FACTS do not contain the answer, say "The database does not contain that." and suggest what could be searched instead.
4. Keep the answer under 180 words. Plain text, short paragraphs, no markdown headings.
5. "recommendations": up to 3 concrete next steps grounded in FACTS (a dataset or finding to look at, a variable
   that is missing, a comparison to make). Each must cite at least one ID. Use an empty list if none apply.
6. Similar conditions do not guarantee the same outcome; user uploads are not reviewed. Say so when relevant."""

SCHEMA = {
    "type": "object",
    "properties": {
        "answer": {"type": "string"},
        "recommendations": {"type": "array", "items": {"type": "object", "properties": {
            "title": {"type": "string"}, "detail": {"type": "string"},
            "citations": {"type": "array", "items": {"type": "string"}}},
            "required": ["title", "detail", "citations"]}},
    },
    "required": ["answer", "recommendations"],
}


def _catalog(motor):
    b = motor.srv.b
    out = []
    for inv_id, inv in b.inv.items():
        P = b.perfil_inv.get(inv_id, {})
        out.append({"id": inv_id, "title": inv.get("title"), "acronym": inv.get("acronym"),
                    "origin": "user_upload" if inv.get("origin") == "user_upload" else "NASA PSI",
                    "experiments": P.get("n_experimentos", 0), "fuels": sorted(P.get("combustibles", {})),
                    "gravity": sorted(P.get("gravedad", {})),
                    "variables": [b.variables[v].label for v in P.get("rangos", {})][:12]})
    return out


def _current_investigation(motor, inv_id):
    if not inv_id or inv_id not in motor.srv.b.inv:
        return None
    try:
        from .investigations_api import _analysis
        a, _, _ = _analysis(motor, inv_id)
    except Exception as exc:  # noqa: BLE001
        current_app.logger.warning("assistant context failed: %s", exc)
        return None
    return {"id": inv_id, "title": a["overview"]["title"], "fuel": a["overview"]["fuel"],
            "variables": a["overview"]["variables"], "experiments": a["overview"]["experiments"],
            "most_related": [{"investigation": x["investigation_id"], "affinity": x["total"], "level": x["level"],
                              "reasons": x["reasons"]} for x in a["affinity"][:4]],
            "your_ranges": [{"variable": r["label"], "min": r["yours"]["min"], "max": r["yours"]["max"], "unit": r["unit"],
                             "tested_by": [{"investigation": t["investigation_id"], "status": t["status"]} for t in r["investigations"]]}
                            for r in a["ranges"]]}


def _sources(motor, query):
    rk = motor.ranking(query, k=K_SOURCES)
    items, pos = motor.srv.sem.items, motor.srv.sem.pos
    out = []
    for x in rk["resultados"]:
        it = items[pos[x["id"]]]
        out.append({"id": x["id"], "type": TYPE_EN.get(x["tipo"], x["tipo"]), "investigation": x["investigacion"],
                    "text": it["texto"][:SOURCE_CHARS], "page": x.get("pagina")})
    return out


def _clean_sentences(text, facts):
    """Keep only sentences whose IDs and numbers are backed by FACTS."""
    kept, dropped = [], 0
    for para in [p.strip() for p in re.split(r"\n\s*\n|\n", text) if p.strip()]:
        good = []
        for sent in re.split(r"(?<=[.!?])\s+(?=[A-Z\[])", para):
            if not sent.strip():
                continue
            if validar(sent, facts):
                dropped += 1
            else:
                good.append(sent.strip())
        if good:
            kept.append(" ".join(good))
    return "\n\n".join(kept), dropped


def _allowed(facts):
    s = json.dumps(facts, ensure_ascii=False)
    return {m.rstrip(".:-") for m in re.findall(r"(?:FND|DS|CHK|DOC):[A-Za-z0-9_.:\-]+|PSI-\d+(?::[A-Za-z0-9_.:\-]+)?", s)}


@assistant_api.post("")
def ask():
    motor = current_app.extensions.get("motor")
    if motor is None:
        return jsonify(error="The assistant is not available: " + str(current_app.extensions.get("motor_error"))), 503
    body = request.get_json(silent=True) or {}
    message = str(body.get("message", "")).strip()[:1500]
    if len(message) < 2:
        return jsonify(error="Write a question."), 400
    history = [h for h in (body.get("history") or []) if isinstance(h, dict) and h.get("role") in ("user", "assistant")][-MAX_HISTORY:]
    ctx = body.get("context") or {}
    current = _current_investigation(motor, str(ctx.get("investigation_id") or "").strip())

    # retrieval: this question + the previous user question (follow-ups like "and at 2 bar?")
    prev_user = next((h["content"] for h in reversed(history) if h["role"] == "user"), "")
    query = " ".join([message, str(prev_user)[:300], current["title"] if current else ""]).strip()
    sources = _sources(motor, query)
    facts = {"question": message, "page": ctx.get("page"), "investigations_catalog": _catalog(motor),
             "current_investigation": current, "sources": sources}
    allowed = _allowed(facts)

    out = {"answer": "", "recommendations": [], "removed_statements": 0, "source": "template", "note": ""}
    try:
        if not llm.servidores():
            raise RuntimeError("QWEN_URL is not configured")
        convo = "\n".join(f"{h['role'].upper()}: {str(h.get('content', ''))[:600]}" for h in history)
        user = (f"CONVERSATION SO FAR (context only; it is not a source):\n{convo}\n\n" if convo else "") + \
               "FACTS:\n" + json.dumps(facts, ensure_ascii=False, default=str) + f"\n\nQUESTION: {message}"
        raw = json.loads(llm.generar(SYSTEM, user, max_tokens=900, esquema=SCHEMA))
        answer, dropped = _clean_sentences(str(raw.get("answer", "")), facts)
        recs = []
        for r in raw.get("recommendations") or []:
            cits = [str(c).strip("[] ") for c in r.get("citations") or []]
            txt = f"{r.get('title', '')}. {r.get('detail', '')}"
            if cits and all(c in allowed for c in cits) and not validar(txt, facts):
                recs.append({"title": str(r.get("title", "")).strip(), "detail": str(r.get("detail", "")).strip(), "citations": cits})
            else:
                dropped += 1
        if not answer:
            answer = "I could not write an answer that the database backs up. These are the most relevant records."
        out.update(answer=answer, recommendations=recs[:3], removed_statements=dropped, source="qwen")
    except Exception as exc:  # noqa: BLE001
        out["answer"] = "The assistant is not available right now. These are the records most related to your question."
        out["note"] = f"{type(exc).__name__}: {str(exc)[:150]}"

    cited = set(ID_RE.findall(out["answer"])) | {c for r in out["recommendations"] for c in r["citations"]}
    out["sources"] = [{k: s[k] for k in ("id", "type", "investigation", "page")} | {"excerpt": s["text"][:220], "cited": s["id"] in cited}
                      for s in sources]
    return jsonify(out)
