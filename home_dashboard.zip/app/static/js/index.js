/* Home (index.html)
 *   GET /api/dashboard -> investigations, points (pressure × oxygen), findings, reference atmospheres
 * Draws everything with plain SVG/HTML (no external libraries), so it also works with no internet.
 * Numbers come from MongoDB; the comparison of a crew atmosphere is plain arithmetic on those points.
 */
(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = (n, d = 1) => Number(n).toLocaleString("en-US", { maximumFractionDigits: d });
  const PALETTE = ["#38BDF8", "#2DD4BF", "#A78BFA", "#F472B6", "#FACC15", "#4ADE80", "#60A5FA", "#F97316"];
  const UPLOAD_COLOR = "#FB923C";
  // "Close" to an atmosphere: within these tolerances (same idea as the matching engine)
  const TOL_O2 = 3;          // percentage points of oxygen
  const TOL_P = 1.42;        // pressure factor (×/÷)

  let data = null;
  const color = {};

  /* ---------------------------------------------------------------- load */
  async function load() {
    try {
      const r = await fetch("/api/dashboard", { headers: { Accept: "application/json" } });
      if (!r.ok) throw new Error(r.status === 404 ? "The /api/dashboard route is not registered in Flask." : `Server error ${r.status}.`);
      data = await r.json();
    } catch (err) {
      const note = $("sourceNote");
      note.hidden = false;
      note.textContent = `Could not load the database: ${err.message}`;
      $("studyList").innerHTML = '<li class="muted-text">No data.</li>';
      return;
    }
    let k = 0;
    data.investigations.forEach((inv) => { color[inv.id] = inv.user_upload ? UPLOAD_COLOR : PALETTE[k++ % PALETTE.length]; });

    const s = data.summary;
    const note = $("sourceNote");
    note.hidden = false;
    note.textContent = `${fmt(s.experiments, 0)} experiments from ${s.investigations} investigations in the database` +
      (s.user_uploads ? ` (${s.user_uploads} uploaded by users)` : "") + `. ${fmt(s.points, 0)} report both pressure and oxygen and appear on the map.`;

    renderStudies();
    renderFindings();
    renderMap();
    renderTable();
    setupMission();
  }

  /* ------------------------------------------------------------- studies */
  function renderStudies() {
    const ul = $("studyList");
    ul.innerHTML = data.investigations.map((inv) => {
      const name = inv.acronym ? `${inv.acronym}: ${inv.title || ""}` : (inv.title || "");
      const href = inv.user_upload ? `/suggestion?investigation=${encodeURIComponent(inv.id)}` : null;
      const fuels = inv.fuels.length ? ` Fuels: ${inv.fuels.join(", ").replace(/_/g, " ")}.` : "";
      return `<li title="${esc(name + "." + fuels)}">
        <span class="swatch" style="background:${color[inv.id]}"></span>
        <span class="study-id">${href ? `<a href="${href}">${esc(inv.id)}</a>` : esc(inv.id)}</span>
        <span class="study-name">${esc(name)}${inv.user_upload ? ' <span class="tag">User upload</span>' : ""}</span>
        <span class="study-count">${inv.experiments}</span>
      </li>`;
    }).join("") || '<li class="muted-text">The database has no investigations yet.</li>';
  }

  /* ------------------------------------------------------------ findings */
  function renderFindings() {
    $("findingList").innerHTML = data.findings.map((f) => `
      <li>
        <p class="finding-text">${esc(f.statement)}</p>
        <p class="muted-text"><span class="swatch-inline" style="background:${color[f.investigation] || "#8A93A6"}"></span>${esc(f.investigation)}${
          f.type ? ` · ${esc(String(f.type).replace(/_/g, " "))}` : ""}</p>
      </li>`).join("") || '<li class="muted-text">No findings recorded yet.</li>';
  }

  /* ----------------------------------------------------------------- map */
  function scale(lo, hi, a, b, log) {
    const f = log ? Math.log10 : (v) => v;
    let L = f(lo), H = f(hi);
    const pad = (H - L) * 0.06 || 0.5; L -= pad; H += pad;
    const s = (v) => a + ((f(v) - L) / (H - L)) * (b - a);
    s.inv = (px) => { const t = L + ((px - a) / (b - a)) * (H - L); return log ? 10 ** t : t; };
    return s;
  }

  function outcomeText(p) {
    const ign = p.hot_ignition == null ? "" : `ignition: ${p.hot_ignition}`;
    const end = p.termination === "self_extinguished" ? "went out on its own" : p.termination === "flow_terminated" ? "burned until the fuel was cut" : "";
    return [ign, end].filter(Boolean).join(", ");
  }

  function renderMap() {
    const box = $("atmosphereMap");
    const pts = data.points;
    const refs = data.references;
    if (!pts.length) { box.innerHTML = '<p class="muted-text map-empty">No experiment reports both pressure and oxygen yet.</p>'; return; }
    const W = 760, H = 440, L = 64, R = 18, T = 18, B = 50;
    const xs = pts.map((p) => p.oxygen_pct).concat(refs.map((r) => r.oxygen_pct));
    const ys = pts.map((p) => p.pressure_kpa).concat(refs.map((r) => r.pressure_kpa));
    const sx = scale(Math.min(...xs), Math.max(...xs), L, W - R, false);
    const sy = scale(Math.min(...ys), Math.max(...ys), H - B, T, true);

    let g = "";
    for (let i = 0; i <= 5; i++) {
      const px = L + (i / 5) * (W - R - L), py = (H - B) - (i / 5) * (H - B - T);
      g += `<line class="map-grid" x1="${px}" x2="${px}" y1="${T}" y2="${H - B}"/>`;
      g += `<line class="map-grid" x1="${L}" x2="${W - R}" y1="${py}" y2="${py}"/>`;
      g += `<text class="map-tick" x="${px}" y="${H - B + 18}" text-anchor="middle">${fmt(sx.inv(px), 0)}%</text>`;
      g += `<text class="map-tick" x="${L - 8}" y="${py + 4}" text-anchor="end">${fmt(sy.inv(py), 0)}</text>`;
    }
    g += `<line class="map-ref-line" x1="${sx(21)}" x2="${sx(21)}" y1="${T}" y2="${H - B}"/>`;
    g += `<text class="map-ref-note" x="${sx(21) + 6}" y="${T + 12}">21% O₂ (air)</text>`;
    g += `<text class="map-axis" x="${(L + W - R) / 2}" y="${H - 8}" text-anchor="middle">Ambient oxygen (%)</text>`;
    g += `<text class="map-axis" transform="translate(16 ${(T + H - B) / 2}) rotate(-90)" text-anchor="middle">Pressure (kPa, log)</text>`;

    pts.forEach((p, i) => {
      g += `<circle class="map-pt${p.termination === "flow_terminated" ? " is-sustained" : ""}" cx="${sx(p.oxygen_pct).toFixed(1)}" cy="${sy(p.pressure_kpa).toFixed(1)}" r="4"
              fill="${color[p.investigation] || "#8A93A6"}" style="animation-delay:${Math.min(i * 2, 900)}ms">
              <title>${esc(p.id)} · ${esc((p.fuel || "fuel n/a").replace(/_/g, " "))} · ${fmt(p.pressure_kpa)} kPa, ${fmt(p.oxygen_pct)}% O₂${outcomeText(p) ? " · " + esc(outcomeText(p)) : ""}</title></circle>`;
    });

    refs.forEach((r) => {
      const x = sx(r.oxygen_pct), y = sy(r.pressure_kpa);
      g += `<g class="map-ref" data-key="${esc(r.key)}">
              <circle class="map-ref-ring" cx="${x}" cy="${y}" r="14"/>
              <path class="map-ref-cross" d="M${x - 7} ${y}H${x + 7}M${x} ${y - 7}V${y + 7}"/>
              <text class="map-ref-label" x="${x + 18}" y="${y - 10}">${esc(r.name)}</text>
            </g>`;
    });
    g += `<g id="mapCustom" class="map-ref map-ref--custom" hidden></g>`;

    box.innerHTML = `<svg class="map-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Experiments by ambient oxygen and pressure">${g}</svg>
      <ul class="map-legend">${data.investigations.filter((i) => i.points).map((i) =>
        `<li><span class="swatch-inline" style="background:${color[i.id]}"></span>${esc(i.id)} <span class="muted-text">${i.points}</span></li>`).join("")}
        <li><span class="swatch-inline is-ring"></span>Burned until the fuel was cut</li>
        <li><span class="map-legend-cross">+</span>Crew atmosphere</li></ul>`;
    box.dataset.scale = "1";
    box._sx = sx; box._sy = sy;
  }

  function markCustom(p, o2) {
    const box = $("atmosphereMap"), g = document.getElementById("mapCustom");
    if (!g || !box._sx) return;
    if (p == null) { g.setAttribute("hidden", ""); return; }
    const x = box._sx(o2), y = box._sy(p);
    g.removeAttribute("hidden");
    g.innerHTML = `<circle class="map-ref-ring" cx="${x}" cy="${y}" r="14"/><path class="map-ref-cross" d="M${x - 7} ${y}H${x + 7}M${x} ${y - 7}V${y + 7}"/>
      <text class="map-ref-label" x="${x + 18}" y="${y - 10}">Custom</text>`;
  }

  function highlightRef(key) {
    document.querySelectorAll(".map-ref").forEach((g) => g.classList.toggle("is-active", g.dataset.key === key || (key === "custom" && g.id === "mapCustom")));
  }

  /* --------------------------------------------------------------- table */
  function renderTable() {
    const rows = [...data.points].sort((a, b) => a.investigation.localeCompare(b.investigation) || a.oxygen_pct - b.oxygen_pct);
    $("mapTable").innerHTML = `<table class="data-table">
      <thead><tr><th>Experiment</th><th>Investigation</th><th>Fuel</th><th class="num">Pressure (kPa)</th><th class="num">O₂ (%)</th><th>Outcome</th></tr></thead>
      <tbody>${rows.map((p) => `<tr><td>${esc(p.id)}</td><td>${esc(p.investigation)}</td><td>${esc((p.fuel || "n/a").replace(/_/g, " "))}</td>
        <td class="num">${fmt(p.pressure_kpa)}</td><td class="num">${fmt(p.oxygen_pct)}</td><td>${esc(outcomeText(p) || "not reported")}</td></tr>`).join("")}</tbody></table>`;
  }

  /* --------------------------------------------------- crew atmosphere */
  function nearest(p, o2) {
    let best = null, bestD = Infinity;
    const close = [];
    data.points.forEach((pt) => {
      const dz = Math.max(Math.abs(pt.oxygen_pct - o2) / TOL_O2, Math.abs(Math.log(pt.pressure_kpa / p)) / Math.log(TOL_P));
      if (dz < bestD) { bestD = dz; best = pt; }
      if (dz <= 1) close.push(pt);
    });
    return { best, close };
  }

  function showMission() {
    const key = $("missionSelect").value;
    let p, o2, label;
    if (key === "custom") {
      p = parseFloat(String($("customP").value).replace(",", "."));
      o2 = parseFloat(String($("customO2").value).replace(",", "."));
      label = "Custom atmosphere";
      if (!(p > 0) || !(o2 > 0 && o2 <= 100)) {
        $("missionResult").innerHTML = '<p class="muted-text">Enter a pressure in kPa and an oxygen percentage between 0 and 100.</p>';
        markCustom(null); return;
      }
      markCustom(p, o2);
    } else {
      const r = data.references.find((x) => x.key === key);
      p = r.pressure_kpa; o2 = r.oxygen_pct; label = r.name; markCustom(null);
    }
    highlightRef(key);
    if (!data.points.length) { $("missionResult").innerHTML = '<p class="muted-text">No tested points to compare with.</p>'; return; }

    const { best, close } = nearest(p, o2);
    const dO2 = best.oxygen_pct - o2;
    const ended = close.filter((c) => c.termination === "self_extinguished" || c.termination === "flow_terminated");
    const kept = ended.filter((c) => c.termination === "flow_terminated").length;
    const ignited = close.filter((c) => c.hot_ignition === "yes" || c.hot_ignition === "flash").length;
    const withIgn = close.filter((c) => c.hot_ignition != null).length;
    const pTxt = best.pressure_kpa >= p ? `${fmt(best.pressure_kpa / p, 2)}× higher pressure` : `${fmt(p / best.pressure_kpa, 2)}× lower pressure`;
    const q = `My cabin is at ${fmt(p)} kPa with ${fmt(o2)}% oxygen. What did similar tests show?`;

    $("missionResult").innerHTML = `
      <p class="muted-text">${esc(label)} · ${fmt(p)} kPa, ${fmt(o2)}% O₂</p>
      <div class="gap-figure">${close.length}</div>
      <p class="muted-text">tests within ±${TOL_O2} O₂ points and ×${TOL_P} pressure</p>
      ${close.length ? `<ul class="mission-stats">
          <li><span>Ignited</span><strong>${withIgn ? `${ignited} of ${withIgn}` : "n/a"}</strong></li>
          <li><span>Went out on their own</span><strong>${ended.length ? `${ended.length - kept} of ${ended.length}` : "n/a"}</strong></li>
          <li><span>Burned until fuel was cut</span><strong class="${kept ? "is-warn" : ""}">${ended.length ? `${kept} of ${ended.length}` : "n/a"}</strong></li>
        </ul>` : `<p class="nearest">No test is that close. These conditions are outside what the database covers.</p>`}
      <p class="nearest">Nearest test: <span class="exp-id">${esc(best.id)}</span> at ${fmt(best.pressure_kpa)} kPa, ${fmt(best.oxygen_pct)}% O₂
        (${dO2 >= 0 ? "+" : ""}${fmt(dO2)} O₂ points, ${pTxt})${outcomeText(best) ? `: ${esc(outcomeText(best))}` : ""}.</p>
      <button type="button" class="text-link mission-ask">Ask the assistant about this atmosphere →</button>`;
    $("missionResult").querySelector(".mission-ask").onclick = () => askAssistant(q);
  }

  // open the database assistant (assistant.js) with the question already written
  function askAssistant(q) {
    const fab = document.querySelector(".psi-assist-fab");
    if (!fab) return;
    if (document.getElementById("psiAssistPanel")?.hidden) fab.click();
    const input = document.getElementById("psiAssistInput");
    if (input) { input.value = q; input.focus(); }
  }

  function setupMission() {
    const sel = $("missionSelect");
    sel.addEventListener("change", () => { $("customFields").hidden = sel.value !== "custom"; showMission(); });
    ["customP", "customO2"].forEach((id) => $(id).addEventListener("input", () => { if (sel.value === "custom") showMission(); }));
    showMission();
  }

  load();
})();
