"""
Data for Home (index.html).

    GET /api/dashboard -> {summary, investigations, points, findings, references}

Everything is read from MongoDB on each request, so new uploads appear without restarting.
  investigations : every investigation in the database (NASA PSI and user uploads) with its experiment count
  points         : each experiment that reports both ambient pressure and ambient oxygen, with its outcome
  findings       : the scientific findings recorded for those investigations
  references     : the crew atmospheres the dashboard compares against (app constants, not database records)
"""
from __future__ import annotations

from collections import Counter, defaultdict

from flask import Blueprint, current_app, jsonify

dashboard_api = Blueprint("dashboard_api", __name__, url_prefix="/api/dashboard")

PRESSURE, OXYGEN = "pressure", "ambient_oxygen_mole_fraction"
REFERENCES = [
    {"key": "exploration", "name": "Exploration atmosphere", "pressure_kpa": 56.5, "oxygen_pct": 34.0},
    {"key": "iss", "name": "ISS cabin", "pressure_kpa": 101.3, "oxygen_pct": 21.0},
]
MAX_FINDINGS = 6
SKIP_FINDING_TYPES = {"method_note"}


def _value(doc, var):
    for r in (doc.get("conditions") or []) + (doc.get("measurements") or []):
        if r.get("variable") == var and r.get("status") == "reported":
            v = (r.get("norm") or {}).get("value")
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                return float(v)
    return None


def _outcome(doc, var):
    for r in doc.get("outcomes") or []:
        if r.get("variable") == var and r.get("status") == "reported":
            return (r.get("norm") or {}).get("value")
    return None


@dashboard_api.get("")
def dashboard():
    db = current_app.extensions["db"]
    invs = {d["_id"]: d for d in db.investigations.find({}, {"title": 1, "acronym": 1, "origin": 1, "sub_research_area": 1})}

    counts, fuels = Counter(), defaultdict(Counter)
    points = []
    for e in db.experiments.find({}, {"investigation_id": 1, "fuel": 1, "conditions": 1, "measurements": 1,
                                      "outcomes": 1, "data_origin": 1}):
        inv = e.get("investigation_id")
        counts[inv] += 1
        fuel = (e.get("fuel") or {}).get("canonical")
        if fuel:
            fuels[inv][fuel] += 1
        p, o2 = _value(e, PRESSURE), _value(e, OXYGEN)
        if p is None or o2 is None:
            continue
        points.append({"id": e["_id"], "investigation": inv, "fuel": fuel,
                       "pressure_kpa": round(p / 1000, 3), "oxygen_pct": round(o2 * 100, 2),
                       "origin": e.get("data_origin"),
                       "hot_ignition": _outcome(e, "hot_ignition"), "termination": _outcome(e, "termination_mode")})

    investigations = []
    for inv_id, d in invs.items():
        investigations.append({"id": inv_id, "title": d.get("title"), "acronym": d.get("acronym"),
                               "area": d.get("sub_research_area"),
                               "user_upload": d.get("origin") == "user_upload",
                               "experiments": counts.get(inv_id, 0),
                               "fuels": [f for f, _ in fuels[inv_id].most_common(4)],
                               "points": sum(1 for p in points if p["investigation"] == inv_id)})
    # NASA studies first, then uploads; larger studies first inside each group
    investigations.sort(key=lambda x: (x["user_upload"], -x["experiments"], x["id"]))

    # findings: results only (no method notes), taken in turns from each investigation so one study does not fill the list
    by_inv = defaultdict(list)
    for f in db.scientific_findings.find({}, {"investigation_id": 1, "statement": 1, "statement_type": 1}):
        if f.get("statement") and f.get("statement_type") not in SKIP_FINDING_TYPES:
            by_inv[f.get("investigation_id")].append({"id": f["_id"], "investigation": f.get("investigation_id"),
                                                      "statement": f.get("statement"), "type": f.get("statement_type")})
    findings = []
    while len(findings) < MAX_FINDINGS and any(by_inv.values()):
        for inv in sorted(by_inv):
            if by_inv[inv] and len(findings) < MAX_FINDINGS:
                findings.append(by_inv[inv].pop(0))

    return jsonify(
        summary={"investigations": len(investigations), "experiments": sum(counts.values()), "points": len(points),
                 "user_uploads": sum(1 for x in investigations if x["user_upload"])},
        investigations=investigations, points=points, findings=findings, references=REFERENCES)
